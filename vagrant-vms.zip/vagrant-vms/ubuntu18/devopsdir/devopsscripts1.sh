#!/bin/bash
echo "Welcome to Bash Scripting."
sudo apt update

echo "Completed successfully."